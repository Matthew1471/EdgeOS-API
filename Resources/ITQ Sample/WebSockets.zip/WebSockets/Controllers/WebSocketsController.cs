﻿using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using Microsoft.Web.WebSockets;

namespace WebSockets.Controllers
{
    public class WebSocketsController : ApiController
    {
        public HttpResponseMessage Get(string name)
        {
            HttpContext.Current.AcceptWebSocketRequest(new ChatSocketHandler(name));
            return new HttpResponseMessage(HttpStatusCode.SwitchingProtocols);
        }

        private class ChatSocketHandler : WebSocketHandler
        {
            private static readonly WebSocketCollection Sockets = new WebSocketCollection();

            private readonly string _name;

            public ChatSocketHandler(string name)
            {
                _name = name;
            }

            public override void OnOpen()
            {
                Sockets.Add(this);
                Sockets.Broadcast(string.Format("{0} joined.", _name));
                Send(string.Format("Welcome {0}.", _name));
            }

            public override void OnMessage(string message)
            {
                Sockets.Broadcast(string.Format("{0} says: {1}", _name, message));
            }

            public override void OnClose()
            {
                Sockets.Remove(this);
                Sockets.Broadcast(string.Format("{0} left.", _name));
            }
        }
    }
}
